#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
  float pies, pulgadas, yardas, centimetros, metros;
  
  printf("Este programa muestra las conversiones de pies a pulgadas,yarda,cm y m\n");
 
  scanf("%f",&pies);
  pulgadas=pies*12;
  yardas=pies*0.3333;
  centimetros=pies/0.0328;
  metros=pies/3.2808;

  
  printf("Conversiones\nPulgadas=%f\nYarda=%f\nCentimetros=%f\Metros=%f\n",pulgadas,yardas,centimetros,metros);
  
  system("PAUSE");	
  return 0;
}

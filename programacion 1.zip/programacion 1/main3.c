#include <stdio.h>
#include <stdlib.h>
#define pi 3.1416
int main(int argc, char *argv[])
{
  float radio, altura, area, volumen, g;
  
  
 
  printf("valor del radio:");
  scanf("%f",&radio);
  
  printf("valor de la altura:");
  scanf("%f",&altura);
  g=sqrt((radio*radio)+(altura*altura));
  area=(2*pi*radio*g/2)+(pi*radio*radio);
  
  
  volumen=(pi*radio*radio*altura)/3;
  printf("Imprimir el volumen del cono:%f\n", volumen);
  printf("Imprimir el area del cono:%f\n",area);
  
  
  
  system("PAUSE");	
  return 0;
}

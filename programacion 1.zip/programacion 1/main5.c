#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) 
{
  float diesel,agua,p,d,densidad,h,V;
  char fluido;
  const float g=9.8;
  const float pi=3.14;
  const int dA=1000;
  const int dD=820;
  
  printf("seleccionar el fluido, ya sea a para agua o d para diesel\n");
  scanf("%c", &fluido);
  
  printf("Introduzca el diametro en metros: ");
  scanf("%f",&d);
  printf("Introduzca la presion:");
  scanf("%f",&p);
  
  densidad=(fluido=='A')?dA:dD;
  
  h=(p/densidad*g);
  
  printf("la altura es igual (h): %f\n",h);
  
  V=pi*d*d*h;
  printf("El volumen es: %f\n",V);
  
  system("PAUSE");	
  return 0;
}

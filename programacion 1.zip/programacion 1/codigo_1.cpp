#include <stdio.h>

int main(){
	double y;
	int grados;
	char letra;

	printf("Ingrese grados y Escala (F o C)\n");
	scanf("%d %c",&grados, &letra);
	
	y= (letra == 'F') ? ( grados -32 ) / 1.8 : (1.8*grados) + 32 ;
	
	printf ("%f", y);
	printf( (letra == 'F') ? "C" :"F");
}
